<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div class="login-container">
        
        <form class="login-form" action="login.php" method="post" onsubmit="return redirectToNextPage()">
            
            <input type="text" name="year" placeholder="Year" required><br>
            <input type="text" name="div" placeholder="Division" required><br>
            <input type="submit" name="save" value="Login">
        </form>

    </div>
</body>
</html>