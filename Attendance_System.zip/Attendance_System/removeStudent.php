<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>


<form  method="post">

  <label for="class">class:</label><br>
  <input type="text" id="class" name="class" required><br><br>

  <label for="div">Div:</label><br>
  <input type="text" id="div" name="div" required><br><br>
  <label for="GRN_No">GRN no:</label><br>
  <input type="text" id="GRN_No" name="GRN_No" required><br><br>
  
  <input type="submit" value="Submit">
</form>

</body>
</html>


<?php
 $conn= new mysqli("localhost","root","","attendance_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



$GRN =$_POST['GRN_No'];
$class= $_POST['class'];
$div = $_POST['div'];


if($class=='ty' && $div=='a')
{
  $table='ty_a';
}elseif($class=='ty' && $div=='b')
{
  $table='ty_b';
}elseif($class=='ty' && $div=='c')
{
  $table='ty_c';
}else
{
  echo "invalid class";
  exit();
}



$sql = " delete from $table where GRN_No=$GRN ";

if ($conn->query($sql) === TRUE) {
    echo "record deleted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
?>

