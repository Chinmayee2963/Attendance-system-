<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="Teacher.php" method="post" >
	<button type="submit" name="FY" >FY</button>
	<button type="submit" name="SY" >SY</button>
	<button type="submit" name="TY" >TY</button>
	</form>

	
</body>
</html>