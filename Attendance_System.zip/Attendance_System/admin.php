<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	here is admin work
	 (name, username, password, idno, phone, teaching_subject, education, position)
</body>
</html>