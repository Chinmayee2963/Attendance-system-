<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Information Form</title>
</head>
<body>

<h2>Admin Information Form</h2>

<form  method="post">

  <label for="name">Name:</label><br>
  <input type="text" id="name" name="name" required><br><br>

  <label for="username">User Name:</label><br>
  <input type="text" id="username" name="username" required><br><br>

  <label for="password">Password:</label><br>
  <input type="text" id="password" name="password" required><br><br>

  <label for="id">ID Number:</label><br>
  <input type="text" id="id" name="id" required><br><br>

  <label for="phone">Phone Number:</label><br>
  <input type="text" id="phone" name="phone" required><br><br>

  <label for="teaching_subject">Teaching Subject:</label><br>
  <input type="text" id="teaching_subject" name="teaching_subject" required><br><br>

  <label for="education">Education:</label><br>
  <input type="text" id="education" name="education" required><br><br>

  <label for="position">Position:</label><br>
  <input type="text" id="position" name="position" required><br><br>

  <input type="submit" value="Submit">
</form>

</body>
</html>

<?php
 $conn= new mysqli("localhost","root","","attendance_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$name = $_POST['name'];
$username =$_POST['username'];
$password= $_POST['password'];
$id = $_POST['id'];
$phone = $_POST['phone'];
$teaching_subject = $_POST['teaching_subject'];
$education = $_POST['education'];
$position = $_POST['position'];


$sql = "insert into teacher values('$name', '$username', '$password','$id', '$phone', '$teaching_subject', '$education', '$position')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
?>


