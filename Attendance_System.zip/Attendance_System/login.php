
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/bootstram.min.css">
    <title></title>
    <style>
        /* Your CSS styles here */
    </style>
</head>
<body>
	<table>
		
    <?php
       $con= new mysqli("localhost","root","","attendance_system");
 	if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }
    	
       	$option=$_POST['user_type'];


    
   
    
    if($option==='Student')
	{
		header("Location:StudentLogin.php");
	}

	if($option=== 'Teacher')
	{
		$username=$_POST['username'];
    $password=$_POST['password'];
		 $sql1="select *from teacher where username='$username' and password='$password'";
 		 $result1= $con->query($sql1);
	  	if ($result1->num_rows>0) 
	    {
	    
        if(isset($_POST["save"]))
            {
                header('Location:class.php');
                echo "<script>alert('succesfully Login');</script>";
                
            }
	    }
	    else
	    {
	    	echo "<script>alert('Unsuccesfully Login');</script>";
	    }
	}

  if($option=== 'Admin')
  {
    $username=$_POST['username'];
    $password=$_POST['password'];
     $sql1="select *from teacher where username='$username' and password='$password'";
     $result1= $con->query($sql1);
      if ($result1->num_rows>0) 
      {
      
        if(isset($_POST["save"]))
            {
                header('Location:adminOperation.php');
          echo "<script>alert('Unsuccesfully Login');</script>";
                
            }
      }
      else
      {
        echo "<script>alert('Unsuccesfully Login');</script>";
      }


  }
    $con->close();

    /*if(!empty($_POST['save']))
       {
       	$username=$_POST['username'];
       	$password=$_POST['password'];
       	$query="select *from student where username='$username' and password='$password'";
       	$result=mysqli_query($con, $query);
       	$count=mysqli_num_rows($result);
       		if($count >0)
       		{
       			echo "login succesfully";
       		}
       		else
       		{
       			echo "log in not succesfully";
       		}

       }
*/
    

   ?>
   </table>
</body>

</html>



