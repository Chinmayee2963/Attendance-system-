<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Type Form</title>
<script>
function showFields() {
    var userType = document.getElementById("user_type").value;
    var studentFields = document.getElementById("student_fields");
    var teacherAdminFields = document.getElementById("teacher_admin_fields");

    // Hide all fields initially
    studentFields.style.display = "none";
    teacherAdminFields.style.display = "none";

    // Show fields based on user type
    if (userType === "student") {
        studentFields.style.display = "block";
    } else {
        teacherAdminFields.style.display = "block";
    }
}
</script>
</head>
<body>

<h2>User Type Form</h2>

<form action="process_form.php" method="post">
  <label for="user_type">Select User Type:</label><br>
  <select id="user_type" name="user_type" onchange="showFields()">
    <option value="student">Student</option>
    <option value="teacher">Teacher</option>
    <option value="admin">Admin</option>
  </select><br><br>

  <!-- Fields for students -->
  <div id="student_fields">
    <label for="username">Username:</label><br>
    <input type="text" id="username" name="username_student"><br><br>
  
    <label for="password">Password:</label><br>
    <input type="password" id="password" name="password_student"><br><br>
  
    <label for="year">Year:</label><br>
    <input type="text" id="year" name="year_student"><br><br>
  
    <label for="division">Division:</label><br>
    <input type="text" id="division" name="division_student"><br><br>
  </div>

  <!-- Fields for teachers and admins -->
  <div id="teacher_admin_fields">
    <label for="username">Username:</label><br>
    <input type="text" id="username" name="username_teacher_admin"><br><br>
  
    <label for="password">Password:</label><br>
    <input type="password" id="password" name="password_teacher_admin"><br><br>
  </div>

  <input type="submit" value="Submit">
</form>

</body>
</html>