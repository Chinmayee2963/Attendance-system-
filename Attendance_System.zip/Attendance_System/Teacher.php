<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="Teacher.php" method="post" >
	<button type="submit" name="A" >A</button>
	<button type="submit" name="B" >B</button>
	<button type="submit" name="C" >C</button>
	</form>
	<table>
	<tr>
			<th>Id</th>
			<th>Username</th>
			<th>Password</th>
		</tr>
	


<?php
       $con= new mysqli("localhost","root","","attendance_system");
 	if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }

    if($_SERVER["REQUEST_METHOD"]=="POST")
    {
    	if(isset($_POST["FY"]))
    	{
	    	$sql="select *from fy_a";
	    	 $result= $con->query($sql);
	    	 if($result->num_rows>0)
	    {

	    	while($row=$result->fetch_assoc())
	    	{
	    		echo "<tr> <td>".$row["id"]."</td> <td>".$row["username"]."</td> <td>".$row["password"]."</td></tr>";
	    	}
	    	echo "</table>";
	    }
	    else
	    {
	    	echo "0 result";
	    }
	    }elseif (isset($_POST["SY"])) {

	    		$sql="select *from sy_a";
	    		 $result= $con->query($sql);
	    if($result->num_rows>0)
	    {

	    	while($row=$result->fetch_assoc())
	    	{
	    		echo "<tr> <td>".$row["id"]."</td> <td>".$row["username"]."</td> <td>".$row["password"]."</td></tr>";
	    	}
	    	echo "</table>";
	    }
	    else
	    {
	    	echo "0 result";
	    }

	}
	}elseif (isset($_POST["TY"])) 
	    {
	    	if(isset($_POST["A"]))
    		{
	    		 $sql="select *from ty_a";
		    	 $result= $con->query($sql);
		    	 if($result->num_rows>0)
		   		{

			    	while($row=$result->fetch_assoc())
			    	{
			    		echo "<tr> <td>".$row["id"]."</td> <td>".$row["username"]."</td> <td>".$row["password"]."</td></tr>";
			    	}
			    	echo "</table>";
			    }

		   		}elseif(isset($_POST["B"]))
	    		{
	    			$sql="select *from ty_b";
		    	 $result= $con->query($sql);
		    	 if($result->num_rows>0)
		   		{

			    	while($row=$result->fetch_assoc())
			    	{
			    		echo "<tr> <td>".$row["id"]."</td> <td>".$row["username"]."</td> <td>".$row["password"]."</td></tr>";
			    	}
			    	echo "</table>";
			    }

	   		}elseif(isset($_POST["C"]))
    		{
    			$sql="select *from ty_c";
	    	 $result= $con->query($sql);
	    	 if($result->num_rows>0)
	   		{

		    	while($row=$result->fetch_assoc())
		    	{
		    		echo "<tr> <td>".$row["id"]."</td> <td>".$row["username"]."</td> <td>".$row["password"]."</td></tr>";
		    	}
		    	echo "</table>";
	   		}
	   	}
	    else
	    {
	    	echo "0 result";
	    }

	   
    }

   
    
    $con->close();


   ?> 
</body>
</html>

