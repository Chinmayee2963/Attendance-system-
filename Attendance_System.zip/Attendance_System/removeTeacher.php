<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>


<form  method="post">

  
  <label for="id">ID Number:</label><br>
  <input type="text" id="id" name="id" required><br><br>
   <input type="submit" value="Submit">

</form>

</body>
</html>
