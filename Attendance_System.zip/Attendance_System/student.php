<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/bootstram.min.css">
    <title>Database Table</title>
    <style>
        /* Your CSS styles here */
    </style>
</head>
<body>
    <table>

        
    <?php

       $con= new mysqli("localhost","root","","attendance_system");
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }
        
    //$option=$_POST['option'];
    //if($option==='Student')

    if($_SERVER["REQUEST_METHOD"]=="POST")
    {
        if(isset($_POST["option"]))
        
        if($result->num_rows>0)  //student info block
        {
            echo "Student log in succesfully";
            echo "Student Name: $username";
            echo "\n";
            echo "password: $password";
            //echo <a href ="student.php">Student</a>
        }
            
        else 
        {
            echo "unsuccessfully";
        }
    }

   ?>
   </table>
</body>

</html>

